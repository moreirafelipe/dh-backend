package service;

import model.Filme;

public interface IGradeDeFilmes {

    public Filme getFilme(String nome);
}
