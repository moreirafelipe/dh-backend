package com.example.checkpoint_clinica;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
public class CheckpointClinicaApplication {

    public static void main(String[] args) {
        SpringApplication.run(CheckpointClinicaApplication.class, args);
    }

}
