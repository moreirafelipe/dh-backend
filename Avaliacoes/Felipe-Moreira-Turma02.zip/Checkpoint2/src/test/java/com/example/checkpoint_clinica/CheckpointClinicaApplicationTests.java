package com.example.checkpoint_clinica;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CheckpointClinicaApplicationTests {

    @Test
    void contextLoads() {
    }

}
