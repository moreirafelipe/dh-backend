package service.impl;
import model.Filme;
import service.IGradeDeFilmes;
import java.util.ArrayList;
import java.util.List;

public class GradeDeFilmes implements IGradeDeFilmes {

    private List<Filme> listaFilmes  = new ArrayList<>();

    public void addFilme(Filme filme) {
        listaFilmes.add(filme);
    }

//    Verifica previamente se filme está cadastrado
    public List<Filme> getListaFilmes(String nome) {
        try {
            getFilme(nome);
        } catch(Exception e) {
            System.out.println(e.getMessage());
            return null;
        }
        return listaFilmes;
    }

//    Método que retorna nome de um filme para verificação
    @Override
    public Filme getFilme(String nome) {
        return listaFilmes.stream()
                .filter(filme -> filme.getNome().equalsIgnoreCase(nome))
                .findFirst().orElse(null);
    }
}
