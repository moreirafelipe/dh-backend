package service;

import model.Serie;

public interface ISerie {

    public Serie getSerie(String nome);
}
