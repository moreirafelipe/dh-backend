package service.impl;

import model.Serie;
import service.ISerie;
import java.util.ArrayList;
import java.util.List;

public class GradeDeSeries implements ISerie {

    private List<Serie> listaSeries;

    public GradeDeSeries() {
        this.listaSeries =  new ArrayList<>();
    }

    public List<Serie> getListaSeries(String nome) {
        try {
            getSerie(nome);
        } catch(Exception e) {
            System.out.println(e.getMessage());
            return null;
        }
        return listaSeries;
    }

    public void addSerie(Serie serie) {
        listaSeries.add(serie);
    }

    @Override
    public Serie getSerie(String nome) {
        return listaSeries.stream()
                .filter(serie -> serie.getNome().equalsIgnoreCase(nome))
                .findFirst().orElse(null);
    }
}
